from pointwise import GlyphClient
from pointwise.glyphapi import *

glf = GlyphClient(port=2807, version='3.18.3')
pw = glf.get_glyphapi()

value = pw.BlockUnstructured.getDefault("TRexGrowthRate")
print("Unstructured block T-Rex growth rate =", value, "(1.2)")
c1 = pw.Connector.create()
c2 = pw.Connector.create()
c3 = pw.Connector.create()
c4 = pw.Connector.create()
c2.delete()
c3.delete()
c4.delete()
c5 = pw.Connector.create()
name = c5.getName()
print("Connector name =", name, "(con-2)")

